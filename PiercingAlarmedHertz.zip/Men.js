var investorsData = [
    {
      ProductImg:"71OL+zOndQL._AC_SR736,920_.jpg",
      CompanyName:" The Original Retro Brand",
      Discription: "It's All Good In The Woods",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,

    },
    {
        ProductImg: "https://m.media-amazon.com/images/I/61hjDKNSSYL._AC_SR736,920_.jpg",
        CompanyName: "Quiksilver",
        Discription: "Prime Operator Short Sleeve Tee",
          Amount:"₹299",
        discount:"₹201",
        discounted_price:"₹500",
        Realamount:299,
    },
    {
        ProductImg: "https://images.bewakoof.com/t540/jet-black-half-sleeve-t-shirt-106-1637159816-2.jpg",
        CompanyName: "Mountain Hardwear",
        Discription: "Canyon™ L/S Shirt",
          Amount:"₹299",
        discount:"₹201",
        discounted_price:"₹500",
        Realamount:299,
      },
    {
        ProductImg: "https://images.bewakoof.com/t540/white-half-sleeve-t-shirt-105-1653031889-1.jpg",
        CompanyName: "Calvin Klein",
        Discription: "The Stretch-Cotton Shirt",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://m.media-amazon.com/images/I/81yYY0Dq6wL._AC_SR736,920_.jpg",
        CompanyName: "tentree",
        Discription: "Summer Guitar T-Shirt",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://m.media-amazon.com/images/I/71QdUTlawTL._AC_SR736,920_.jpg",
        CompanyName: "Helly Hansen",
        Discription: "Riftline Polo",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://m.media-amazon.com/images/I/71fAPkW49fL._AC_SR736,920_.jpg",
        CompanyName: "Prana",
        Discription: "Wise Ass Journeyman",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://m.media-amazon.com/images/I/71YKqYLNA7L._AC_SR736,920_.jpg",
        CompanyName: "Quiksilver",
        Discription: "Gold Lines Short Sleeve Tee",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://images.bewakoof.com/t540/navy-blue-full-sleeve-t-shirt-1092-1637995354-1.jpg",
        CompanyName: "Calvin Klein",
        Discription: "The Stretch-Cotton Shirt",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://images.bewakoof.com/t540/navy-blue-half-sleeve-t-shirt-115-1646674268-1.jpg",
        CompanyName: "Calvin Klein",
        Discription: "The Stretch-Cotton Shirt",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://images.bewakoof.com/t540/tropical-blue-half-sleeve-t-shirt-271438-1637995770-1.jpg",
        CompanyName: "Under Armour Golf",
        Discription: "Playoff Polo 2.0",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://m.media-amazon.com/images/I/61AI4zyEGXL._AC_SR736,920_.jpg",
        CompanyName: "Calvin Klein",
        Discription: "Logo Crew Neck Graphic T-Shirt",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://images.bewakoof.com/t540/black-crewneck-varsity-rib-half-sleeves-t-shirt-multicolor-272304-1637855463-1.jpg",
        CompanyName: "Billabong",
        Discription: "Simpsons Duff Delivery Short Sleeve Woven",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://m.media-amazon.com/images/I/71MxPjIwyhL._AC_SR736,920_.jpg",
        CompanyName: "Billabong",
        Discription: "Simpsons Duff Can Short Sleeve Tee",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://images.bewakoof.com/t540/sleet-men-solid-henley-t-shirt-462125-1649996225-1.jpg",
        CompanyName: "Nautica",
        Discription: "Sustainably Crafted Brushed Plaid Shirt",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
        ProductImg: "https://images.bewakoof.com/t540/killmonger-half-sleeve-t-shirt-509349-1655101044-1.jpg",
        CompanyName: "Faherty",
        Discription: "Short Sleeve Knit Seasons Shirt",
        Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/killmonger-oversized-fit-t-shirt-509357-1655101091-1.jpg",
      CompanyName: "Nautica",
      Discription: "Navtech Plaid Short Sleeve Shirt",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/the-dark-side-oversized-fit-t-shirt-509130-1654873148-1.jpg",
      CompanyName: "Tommy Hilfiger Adaptive",
      Discription: "Custom Fit Check Short Sleeve Shirt",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/blue-vibes-half-sleeve-t-shirt-black-298517-1637995543-1.jpg",
      CompanyName: "Original Penguin",
      Discription: "Long Sleeve Dobby Plaid Woven",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/the-traveller-full-sleeve-t-shirt-276528-1638212427-1.jpg",
      CompanyName: "Calvin Klein",
      Discription: "Long Sleeve Pocket Check Easy Shirt",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/throne-of-dragon-oversized-fit-t-shirt-503831-1653666298-1.jpg",
      CompanyName: "Calvin Klein",
      Discription: "Long Sleeve Pocket Check Easy Shirt",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/young-forever-side-half-sleeve-t-shirt-287625-1638021474-1.jpg",
      CompanyName: "NATIVE YOUTH",
      Discription: "Flynn Button-Up Shirt",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/men-s-blue-busy-doing-nothing-t-shirt-287587-1651248151-1.jpg",
      CompanyName: "UNTUCKit",
      Discription: "Wrinkle Free Keaton Shirt",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
    {
      ProductImg: "https://images.bewakoof.com/t540/world-peace-half-sleeve-t-shirt-231465-1637995706-1.jpg",
      CompanyName: "Polo Ralph Lauren",
      Discription: "Classic Fit Checked Oxford Shirt",
      Amount:"₹299",
      discount:"₹201",
      discounted_price:"₹500",
      Realamount:299,
    },
  ];
  var Addarr=JSON.parse(localStorage.getItem("mencart")) ||[]
  var FUllV=JSON.parse(localStorage.getItem("Fullviwe")) ||[]
   dd(investorsData)
  function dd(investorsData){

    investorsData.forEach(function (elem) {

        var box = document.createElement("div");
        var Product = document.createElement("img");
        Product.setAttribute("src", elem.ProductImg);
        var Brand = document.createElement("h6");
        Brand.innerText = elem.CompanyName;
        var Product_discription = document.createElement("p");
        Product_discription.innerText = elem.Discription;
        var Product_amount = document.createElement("p");
        Product_amount.innerText = elem.Amount;
        var Adding = document.createElement("button")
        Adding.innerText = "Add to Cart"
        Adding.setAttribute("id","shanky")
        // style.cursor="pointer"
        Adding.addEventListener("click",function(){
               AddCart(elem)
        })

        let ProductFull={
            p1:elem.ProductImg,
            p2:elem.CompanyName,
            p3:elem.Discription,
            p4:elem.Amount

        }

        Product.onclick=()=>{

           Fullview(ProductFull)

        }

        box.append(Product, Brand, Product_discription, Product_amount,Adding);
        document.querySelector("#Ho_lder").append(box);
      });

  }

  function AddCart(elem){
      Addarr.push(elem)
      alert("Your Product Added Successfully")
      localStorage.setItem("mencart",JSON.stringify(Addarr))
  }

  let Fullview=(ProductFull)=>{
    FUllV.push(ProductFull)
     localStorage.setItem("Fullviwe",JSON.stringify(FUllV))
     window.location.href="Fulldetail.html"

  }

  import footer from "./footer.js"

   document.getElementById("vinay-footer").innerHTML = footer();

   import navbar from "./navbar.js";

document.getElementById("navbar1").innerHTML= navbar();

document.getElementById("logo_1").addEventListener("click",func)

function func(){

    window.location.href="index.html"
}