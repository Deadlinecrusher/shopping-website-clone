var investorsData = [
  {
    ProductImg: "New folder/women-s-purple-oversized-t-shirt-502755-1700657112-1_f51c42ac-35c7-4700-8810-33bcc0ea3050.webp",
    CompanyName: "Women's Purple Oversized T-shirt",
    Discription: "It's All Good In The Woods",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,

  },
  {
    ProductImg: "New folder/women-s-pink-smashed-it-graphic-printed-oversized-t-shirt-636434-1712758724-1_945fdf70-2908-4b6e-aca6-9dd1d99860dd.webp",
    CompanyName: "Smashed Oversized Pink T-shirt",
    Discription: "Prime Operator Oversized Tee",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-white-all-over-printed-oversized-dress-582002-1707221737-1_b5ac4c89-6939-49ab-a9dc-4e395f234bdf.webp",
    CompanyName: "Printed Over-sized Dress",
    Discription: "Canyon™ L/S Shirt",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-blue-solid-dress-42-582050-1704087354-1_a7872df7-e241-44e8-b0ea-fd50b44d7dbf.webp",
    CompanyName: "Shri&Co. Special Oversized Dress",
    Discription: "The Stretch-Cotton oversized Dress",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-green-oversized-t-shirt-502793-1700136632-1_f603774b-547e-4cc2-b5f2-920541b0674d.webp",
    CompanyName: "Women's Green Oversized T-Shirt",
    Discription: "Latest Women's Shri&Co. collection",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-blue-solid-tshirt-23-582040-1688996238-1_2e6bfcde-6835-4619-9144-00b9e77aba30.jpg",
    CompanyName: "Women Blue Solid OverTee",
    Discription: "Women's Choice,Solid Blue Over Tee",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-plain-oversized-fit-t-shirt-24-616047-1698407714-1.webp",
    CompanyName: "Plain Red Overshirt",
    Discription: "Wise women first choice",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-grey-oversized-dress-582067-1708519423-1_f42abdcd-cc1b-4237-bc6d-93a7357c0e0b.webp",
    CompanyName: "Grey Oversized Dress",
    Discription: "Rashmi's Daily wear,Comfy then all of them",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-pink-party-planning-committee-graphic-printed-oversized-t-shirt-585749-1708519418-1_676e9a46-e65b-4728-a43f-f17ac1986131.webp",
    CompanyName: " Pink Overshirt",
    Discription: "Rashmika Mandana,The Stretch-Cotton Shirt",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-purple-oversized-t-shirt-581059-1698407790-1_2ebdc3f6-8890-402e-a9d7-c762b411663e.jpg",
    CompanyName: "Exotic Plain Purple Oversized T-shirt",
    Discription: "Wise women first choice",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-purple-power-up-graphic-printed-oversized-t-shirt-516913-1694764424-1_8a2f0e35-a3a6-4596-8fc8-704578613848.webp",
    CompanyName: "Power Up Pink Oversized-Tee",
    Discription: "Cute RoBo Print, Print Pink Oversized T-shirt, Cotton Blend",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-black-bunny-graphic-printed-oversized-t-shirt-dress-589791-1707215308-1_d518b1fd-27b8-4a95-8e96-3f98a1d2fd0d.webp",
    CompanyName: "Black Bunny Oversized T-Shirt",
    Discription: "Bunny Print Black Oversized Party Wear Dress",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-black-stay-hydrated-back-graphic-printed-oversized-t-shirt-492911-1708436835-1_1c77ad88-479c-4af4-b7fe-9922fd33e67b.webp",
    CompanyName: "Black Printed Over-T-Shirt",
    Discription: "Rashmika Mandana,The Stretch-Cotton Shirt",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  {
    ProductImg: "New folder/women-s-purple-oversized-t-shirt-507615-1675195034-1_2d3568ca-47cb-486b-a30f-2fe9fb5dfe53.webp",
    CompanyName: "Women's Purple Oversized T-shirt",
    Discription: "Plain Purple Over-Tee, Made with Cotton Blend",
    Amount: "₹299",
    discount: "₹201",
    discounted_price: "₹500",
    Realamount: 299,
  },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/sleet-men-solid-henley-t-shirt-462125-1649996225-1.jpg",
  //   CompanyName: "Nautica",
  //   Discription: "Sustainably Crafted Brushed Plaid Shirt",
  //   Amount: "₹299",
  //   discount: "₹201",
  //   discounted_price: "₹500",
  //   Realamount: 299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/killmonger-half-sleeve-t-shirt-509349-1655101044-1.jpg",
  //   CompanyName: "Faherty",
  //   Discription: "Short Sleeve Knit Seasons Shirt",
  //   Amount: "₹299",
  //   discount: "₹201",
  //   discounted_price: "₹500",
  //   Realamount: 299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/killmonger-oversized-fit-t-shirt-509357-1655101091-1.jpg",
  //   CompanyName: "Nautica",
  //   Discription: "Navtech Plaid Short Sleeve Shirt",
  //   Amount: "₹299",
  //   discount: "₹201",
  //   discounted_price: "₹500",
  //   Realamount: 299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/the-dark-side-oversized-fit-t-shirt-509130-1654873148-1.jpg",
  //   CompanyName: "Tommy Hilfiger Adaptive",
  //   Discription: "Custom Fit Check Short Sleeve Shirt",
  //   Amount: "₹299",
  //   discount: "₹201",
  //   discounted_price: "₹500",
  //   Realamount: 299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/blue-vibes-half-sleeve-t-shirt-black-298517-1637995543-1.jpg",
  //   CompanyName: "Original Penguin",
  //   Discription: "Long Sleeve Dobby Plaid Woven",
  //   Amount:"₹299",
  //   discount:"₹201",
  //   discounted_price:"₹500",
  //   Realamount:299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/the-traveller-full-sleeve-t-shirt-276528-1638212427-1.jpg",
  //   CompanyName: "Calvin Klein",
  //   Discription: "Long Sleeve Pocket Check Easy Shirt",
  //   Amount:"₹299",
  //   discount:"₹201",
  //   discounted_price:"₹500",
  //   Realamount:299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/throne-of-dragon-oversized-fit-t-shirt-503831-1653666298-1.jpg",
  //   CompanyName: "Calvin Klein",
  //   Discription: "Long Sleeve Pocket Check Easy Shirt",
  //   Amount:"₹299",
  //   discount:"₹201",
  //   discounted_price:"₹500",
  //   Realamount:299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/young-forever-side-half-sleeve-t-shirt-287625-1638021474-1.jpg",
  //   CompanyName: "NATIVE YOUTH",
  //   Discription: "Flynn Button-Up Shirt",
  //   Amount:"₹299",
  //   discount:"₹201",
  //   discounted_price:"₹500",
  //   Realamount:299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/men-s-blue-busy-doing-nothing-t-shirt-287587-1651248151-1.jpg",
  //   CompanyName: "UNTUCKit",
  //   Discription: "Wrinkle Free Keaton Shirt",
  //   Amount:"₹299",
  //   discount:"₹201",
  //   discounted_price:"₹500",
  //   Realamount:299,
  // },
  // {
  //   ProductImg: "https://images.bewakoof.com/t540/world-peace-half-sleeve-t-shirt-231465-1637995706-1.jpg",
  //   CompanyName: "Polo Ralph Lauren",
  //   Discription: "Classic Fit Checked Oxford Shirt",
  //   Amount:"₹299",
  //   discount:"₹201",
  //   discounted_price:"₹500",
  //   Realamount:299,
  // },
];
var Addarr = JSON.parse(localStorage.getItem("mencart")) || []
var FUllV = JSON.parse(localStorage.getItem("Fullviwe")) || []
dd(investorsData)
function dd(investorsData) {

  investorsData.forEach(function(elem) {

    var box = document.createElement("div");
    var Product = document.createElement("img");
    Product.setAttribute("src", elem.ProductImg);
    var Brand = document.createElement("h6");
    Brand.innerText = elem.CompanyName;
    var Product_discription = document.createElement("p");
    Product_discription.innerText = elem.Discription;
    var Product_amount = document.createElement("p");
    Product_amount.innerText = elem.Amount;
    var Adding = document.createElement("button")
    Adding.innerText = "Add to Cart"
    Adding.setAttribute("id", "shanky")
    // style.cursor="pointer"
    Adding.addEventListener("click", function() {
      AddCart(elem)
    })

    let ProductFull = {
      p1: elem.ProductImg,
      p2: elem.CompanyName,
      p3: elem.Discription,
      p4: elem.Amount

    }

    Product.onclick = () => {

      Fullview(ProductFull)

    }

    box.append(Product, Brand, Product_discription, Product_amount, Adding);
    document.querySelector("#Ho_lder").append(box);
  });

}

function AddCart(elem) {
  Addarr.push(elem)
  alert("Your Product Added Successfully")
  localStorage.setItem("mencart", JSON.stringify(Addarr))
}

let Fullview = (ProductFull) => {
  FUllV.push(ProductFull)
  localStorage.setItem("Fullviwe", JSON.stringify(FUllV))
  window.location.href = "Fulldetail.html"

}

import footer from "./footer.js"

document.getElementById("vinay-footer").innerHTML = footer();

import navbar from "./navbar.js";

document.getElementById("navbar1").innerHTML = navbar();

document.getElementById("logo_1").addEventListener("click", func)

function func() {

  window.location.href = "index.html"
}